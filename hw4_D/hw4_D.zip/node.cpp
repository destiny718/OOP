#include "node.h"
//wait to fill.

void PlaceholderNode::set_val(float val){
    value_=val;
}

void PlaceholderNode::calc() {}

Node::~Node(){}